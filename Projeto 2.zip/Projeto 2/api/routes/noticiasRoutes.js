const controllerNoticias = require('../controllers/noticiasControllers')

app.get('/noticias/noticiasMenu', controllerNoticias.menu)

app.get('/noticias/noticiasSaudeMenu', controllerNoticias.menu)