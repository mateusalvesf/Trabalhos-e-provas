module.exports = {
    menu

}

function menu (req, res) {
    res.render('receitas/frm_receitasMenu.ejs',
        {title: 'Receitas',
            autor: '2º DSM - Web II'
        })
}


 