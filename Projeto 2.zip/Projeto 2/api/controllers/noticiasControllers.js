module.exports = {
    menu
}

function menu(req, res) {
    res.render('noticias/frm_noticiasMenu.ejs', //Formulário (frm)
    {title: 'Noticias',
        autor: '2° DEM - WEB II'
    })
}

function menu(req, res) {
    res.render('noticias/frm_noticiasSaudeMenu.ejs', //Formulário (frm)
    {title: 'Noticias',
        autor: '2° DEM - WEB II'
    })
}