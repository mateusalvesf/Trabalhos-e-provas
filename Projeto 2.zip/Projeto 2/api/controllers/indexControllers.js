module.exports = {
    index
}

function index(req, res) {
    res.render('index.ejs', {title: 'Rotas',
    mensagem: 'Iniciando com NodeJS e Express',
    conteudo: 'Corpo da página - vh x vw',
    autor: '2° DEM - WEB II'
})
}

