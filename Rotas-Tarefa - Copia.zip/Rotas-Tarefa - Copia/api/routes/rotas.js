const controller = require('../controllers/indexControllers.js')
//../controllers/controllers.js')

app.get('/', controller.index);

