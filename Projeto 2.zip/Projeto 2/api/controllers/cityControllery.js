module.exports = {
    menu
}

function menu(req, res) {
    res.render('noticias/frm_noticiasCityMenu.ejs', //Formulário (frm)
    {title: 'Noticias',
        autor: '2° DEM - WEB II'
    })
}

