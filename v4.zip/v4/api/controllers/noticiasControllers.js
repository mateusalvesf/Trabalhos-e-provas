module.exports = {
    menu,
    menuNoticiasEsporteControllers,
    menuNoticiasEsporteFutebolControllers        
}

function menu (req, res) {
    res.render('noticias/frm_noticiasMenu.ejs',
        {title: 'Noticias',
            autor: '2º DSM - Web II'
        })
}


function menuNoticiasEsporteControllers (req, res) {
    res.render('noticias/frm_noticiasEsporteMenu.ejs',
        {title: 'Noticias de Esporte',
            autor: '2º DSM - Web II'
        })
}


function menuNoticiasEsporteFutebolControllers (req, res) {
    res.render('noticias/frm_noticiasEsporteFutebolMenu.ejs',
        {title: 'Noticias de Futebol',
            autor: '2º DSM - Web II'
        })
}


